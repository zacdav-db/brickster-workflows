## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
#  library(brickster)
#  
#  # using db_host() and db_token() to get credentials
#  clusters <- db_cluster_list(host = db_host(), token = db_token())

## -----------------------------------------------------------------------------
#  # all host/token parameters default to db_host()/db_token()
#  clusters <- db_cluster_list()

