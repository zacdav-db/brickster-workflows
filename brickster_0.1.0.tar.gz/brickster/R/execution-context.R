# https://docs.databricks.com/dev-tools/api/1.2/index.html#id36

#' Create an Execution Context
#'
#' @param cluster_id The ID of the cluster to create the context for.
#' @param language The language for the context. One of `python`, `sql`, `scala`,
#' `r`.
#' @inheritParams auth_params
#'
#' @family Execution Context API
#'
#' @export
db_context_create <- function(cluster_id,
                              language = c("python", "sql", "scala", "r"),
                              host = db_host(), token = db_token()) {
  language <- match.arg(language)

  body <- list(
    clusterId = cluster_id,
    language = language
  )

  req <- db_request(
    endpoint = "contexts/create",
    method = "POST",
    version = "1.2",
    body = body,
    host = host,
    token = token
  )

  db_perform_request(req)
}

#' Delete an Execution Context
#'
#' @param context_id The ID of the execution context.
#' @inheritParams auth_params
#' @inheritParams db_context_create
#'
#' @family Execution Context API
#'
#' @export
db_context_destroy <- function(cluster_id,
                               context_id,
                               host = db_host(), token = db_token()) {
  body <- list(
    clusterId = cluster_id,
    contextId = context_id
  )

  req <- db_request(
    endpoint = "contexts/destroy",
    method = "POST",
    version = "1.2",
    body = body,
    host = host,
    token = token
  )

  db_perform_request(req)
}

#' Get Information About an Execution Context
#'
#' @inheritParams auth_params
#' @inheritParams db_context_destroy
#'
#' @family Execution Context API
#'
#' @export
db_context_status <- function(cluster_id,
                              context_id,
                              host = db_host(), token = db_token()) {
  req <- db_request(
    endpoint = "contexts/status",
    method = "GET",
    version = "1.2",
    host = host,
    token = token
  )

  req <- req %>%
    httr2::req_url_query(
      clusterId = cluster_id,
      contextId = context_id
    )

  db_perform_request(req)
}

#' Run a Command
#'
#' @param command The command string to run.
#' @param command_file The path to a file containing the command to run.
#' @param options Named list of values used downstream. For example, a
#' 'displayRowLimit' override (used in testing).
#' @inheritParams auth_params
#' @inheritParams db_context_destroy
#' @inheritParams db_context_create
#'
#' @family Execution Context API
#'
#' @export
db_context_command_run <- function(cluster_id,
                                   context_id,
                                   language = c("python", "sql", "scala", "r"),
                                   command = NULL,
                                   command_file = NULL,
                                   options = list(),
                                   host = db_host(), token = db_token()) {
  language <- match.arg(language)

  # only can have one of `command` or `command_file`
  if (!is.null(command) && !is.null(command_file)) {
    stop("Must `command` OR `command_file` not both.")
  }

  body <- list(
    clusterId = cluster_id,
    contextId = context_id,
    language = language,
    command = command,
    commandFile = command_file,
    options = options
  )

  req <- db_request(
    endpoint = "commands/execute",
    method = "POST",
    version = "1.2",
    body = body,
    host = host,
    token = token
  )

  db_perform_request(req)
}

#' Get Information About a Command
#'
#' @param command_id The ID of the command to get information about.
#' @inheritParams auth_params
#' @inheritParams db_context_status
#'
#' @family Execution Context API
#'
#' @export
db_context_command_status <- function(cluster_id,
                                      context_id,
                                      command_id,
                                      host = db_host(), token = db_token()) {
  req <- db_request(
    endpoint = "commands/status",
    method = "GET",
    version = "1.2",
    host = host,
    token = token
  )

  req <- req %>%
    httr2::req_url_query(
      clusterId = cluster_id,
      contextId = context_id,
      commandId = command_id
    )

  db_perform_request(req)
}

#' Cancel a Command
#'
#' @inheritParams auth_params
#' @inheritParams db_context_command_status
#'
#' @family Execution Context API
#'
#' @export
db_context_command_cancel <- function(cluster_id,
                                      context_id,
                                      command_id,
                                      host = db_host(), token = db_token()) {
  req <- db_request(
    endpoint = "commands/cancel",
    method = "POST",
    version = "1.2",
    host = host,
    token = token
  )

  req <- req %>%
    httr2::req_url_query(
      clusterId = cluster_id,
      contextId = context_id,
      commandId = command_id
    )

  db_perform_request(req)
}
